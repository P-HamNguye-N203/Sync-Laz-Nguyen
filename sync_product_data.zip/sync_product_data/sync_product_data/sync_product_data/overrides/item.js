frappe.ui.form.on("Item", {
    onload: function(frm) {
        if (frm.is_new()) {
            // Ẩn tab khi tạo mới
            frm.set_df_property("custom_sync_to_other_platform", "hidden", 1);
        } else {
            // Kiểm tra số lượng biến thể và variant_of
            frappe.db.count("Item", {filters: {"variant_of": frm.doc.item_code}}).then(function(count) {
                // Hiển thị tab nếu là template (có biến thể) hoặc không phải variant
                frm.set_df_property("custom_sync_to_other_platform", "hidden", (count > 0 || !frm.doc.variant_of) ? 0 : 1);
            });
        }

        // Đảm bảo trường custom_parent_item luôn hiển thị
        frm.set_df_property("custom_parent_item", "hidden", 0);
    },
    refresh: function(frm) {
        // Cập nhật trạng thái hiển thị của tab
        frappe.db.count("Item", {filters: {"variant_of": frm.doc.item_code}}).then(function(count) {
            // Hiển thị tab nếu là template (có biến thể) hoặc không phải variant
            frm.set_df_property("custom_sync_to_other_platform", "hidden", (count > 0 || !frm.doc.variant_of) ? 0 : 1);
        });

        // Logic cho checkbox custom_has_sync_to_other_platform
        if (frm.doc.variant_of) {
            frm.set_df_property("custom_has_sync_to_other_platform", "hidden", 1);
        } else {
            frm.set_df_property("custom_has_sync_to_other_platform", "hidden", 0);
        }

        // Đảm bảo trường custom_parent_item luôn hiển thị
        frm.set_df_property("custom_parent_item", "hidden", 0);

        // Thêm custom button "Flatten Variants"
        if (!frm.doc.variant_of) {
            frm.add_custom_button(__("Flatten Variants"), function() {
                frappe.confirm(
                    __("This will create new independent Items for each active marketplace variant. Continue?"),
                    function() {
                        frappe.call({
                            method: "sync_product_data.sync_product_data.overrides.item.flatten_variants_to_items",
                            args: {
                                item_code: frm.doc.item_code
                            },
                            callback: function(r) {
                                if (r.message && r.message.success) {
                                    frappe.msgprint(__("Variants have been flattened into independent Items."));
                                    frm.reload_doc();
                                } else {
                                    console.log(r);
                                    // Hiển thị thông báo lỗi nếu có
                                    frappe.msgprint(__("Failed to flatten variants: " + (r.message && r.message.error ? r.message.error : "Unknown error")));
                                }
                            }
                        });
                    }
                );
            });
        }
    },
    has_variants: function(frm) {
        // Hiển thị/ẩn tab dựa trên has_variants
        frm.set_df_property("custom_sync_to_other_platform", "hidden", frm.doc.has_variants ? 0 : (!frm.doc.variant_of ? 0 : 1));
    },
    custom_has_sync_to_other_platform: function(frm) {
        console.log(frm.doc.custom_has_sync_to_other_platform);

        if (!frm.doc.variant_of) {
            // Hiển thị/ẩn tab dựa trên checkbox nếu không phải variant
            frm.set_df_property("custom_sync_to_other_platform", "hidden", frm.doc.custom_has_sync_to_other_platform ? 0 : 1);
            // frm.save(); // Lưu thay đổi nếu cần
        }
    },
    // Thêm xử lý cho trường custom_parent_item
    custom_parent_item: function(frm) {
        // Log để debug
        console.log("Custom Parent Item changed: " + frm.doc.custom_parent_item);
    }
});

// Xử lý cập nhật platform từ shop trong child table Item Category Variant
frappe.ui.form.on("Item Category Variant", {
    shop: function(frm, cdt, cdn) {
        var row = locals[cdt][cdn];
        if (row.shop) {
            frappe.db.get_value("Platform Account", row.shop, "platform", function(r) {
                if (r && r.platform) {
                    frappe.model.set_value(cdt, cdn, "platform", r.platform);
                    // Log để debug
                    console.log("Updated platform to: " + r.platform + " for shop: " + row.shop);
                }
                console.log("Updated platform to: " + row.shop);
            });
        } else {
            frappe.model.set_value(cdt, cdn, "platform", "");
        }
    }
});

// Các phần còn lại (Item Category Variant, sync_marketplace_category, v.v.) giữ nguyên