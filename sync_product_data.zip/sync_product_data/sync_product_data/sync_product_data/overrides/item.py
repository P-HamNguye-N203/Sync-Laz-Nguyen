from erpnext.stock.doctype.item.item import Item as BaseItem
import frappe
from frappe import _

# Ensure we explicitly export the flatten_variants_to_items function
__all__ = ['Item', 'flatten_variants_to_items', 'clean_duplicate_attributes', 'copy_child_table']

class Item(BaseItem):
    def on_update(self):
        super().on_update()
        if not self.custom_has_sync_to_other_platform or self.custom_marketplace_source == "ERPNext" or self.variant_of is not None:
            return

        print(f"Queueing update or create process for {self.name}")
        custom_marketplace_source = self.custom_marketplace_source

        # Lấy tất cả active marketplace variants
        active_marketplace_variants = [m for m in (self.custom_marketplace_variant or []) if m.active]
        
        # Nếu không có marketplace nào active, thoát khỏi hàm
        if not active_marketplace_variants:
            print(f"No active marketplace variants for {self.name}")
            return
            
        # Duyệt qua từng marketplace active
        for variant in active_marketplace_variants:
            platform = variant.platform  # Sử dụng platform từ marketplace variant
            shop = getattr(variant, 'shop', None)  # Lấy shop từ marketplace variant
            
            print(f"Processing sync for {self.name} to {platform} - Shop: {shop}")
            
            # Xử lý đồng bộ dựa vào marketplace
            if platform == "Tiktok Shop":
                # Kiểm tra mapping cho Tiktok Shop
                tiktok_mapping = next(
                    (m for m in (self.custom_marketplace_item_mapping or []) 
                     if m.marketplace == "Tiktok Shop" and 
                     m.active and 
                     (not hasattr(m, 'shop') or not m.shop or m.shop == shop)),
                    None
                )
                
                # Đồng bộ sản phẩm với Tiktok Shop
                print(f"Queueing sync for {self.name} to Tiktok Shop - Shop: {shop}")
                frappe.enqueue(
                    "sync_product_data.sync_product_data.tiktok_integration.tiktok_product_sync.update_or_create_tiktok_shop",
                    queue="short",
                    timeout=20,
                    kwargs={"item_doc": self, "shop_name": shop}
                )
            elif platform == "Lazada":
                # Kiểm tra mapping cho Lazada
                lazada_mapping = next(
                    (m for m in (self.custom_marketplace_item_mapping or []) 
                     if m.marketplace == "Lazada" and 
                     m.active and 
                     (not hasattr(m, 'shop') or not m.shop or m.shop == shop)),
                    None
                )
                
                # Đồng bộ sản phẩm với Lazada
                print(f"Queueing sync for {self.name} to Lazada - Shop: {shop}")
                frappe.enqueue(
                    "spec.spec.lazada.lazada_product.update_or_create",
                    queue="short",
                    timeout=20,
                    kwargs={"item_doc": self, "shop_name": shop}
                )
            else:
                print(f"Unsupported platform: {platform} for {self.name} - Shop: {shop}")
    
    def on_trash(self):
        print(f"Deleting {self.name}. Checking marketplace sync.")
        marketplace_variants = self.custom_marketplace_variant or []
        if not marketplace_variants:
            print(f"No marketplace variants for {self.name}. Skipping sync.")
            return super().on_trash()

        for variant in marketplace_variants:
            if not variant.active:
                print(f"Skipping inactive variant for {variant.platform} - Shop: {getattr(variant, 'shop', None)}")
                continue
                
            platform = variant.platform
            shop = getattr(variant, 'shop', None)  # Lấy shop an toàn
            
            print(f"Processing deletion for {self.name} on {platform} - Shop: {shop}")
            
            if platform == "Tiktok Shop":
                from sync_product_data.sync_product_data.tiktok_integration.tiktok_product_sync import delete_tiktok_shop
                delete_tiktok_shop(self, shop)
            elif platform == "Lazada":
                from spec.spec.lazada.lazada_product import delete_lazada_product
                delete_lazada_product(self, shop)
                print(f"Processed Lazada deletion for {self.name} - Shop: {shop}")
            else:
                print(f"Unsupported platform: {platform} for {self.name} - Shop: {shop}")

        super().on_trash()

# Helper function to clean duplicate attributes
def clean_duplicate_attributes(doc):
    """Remove duplicate attributes in tabItem Variant Attribute."""
    attributes = doc.get("attributes") or []
    if not attributes:
        print(f"No attributes found for {doc.name}")
        return
    unique_attributes = {}
    for attr in attributes:
        if not hasattr(attr, "attribute") or not attr.attribute:
            print(f"Invalid attribute entry in {doc.name}: {attr.as_dict()}")
            continue
        if attr.attribute not in unique_attributes:
            unique_attributes[attr.attribute] = attr
        else:
            print(f"Removed duplicate attribute {attr.attribute} in {doc.name}")
    doc.attributes = list(unique_attributes.values())

# Helper function to copy child tables
def copy_child_table(source, target, table_field):
    """Copy child table records if the DocType exists."""
    try:
        source_rows = source.get(table_field) or []
        if not source_rows:
            print(f"No rows found for {table_field} in {source.name}")
            return

        doctype = frappe.get_meta(table_field).options
        if not frappe.db.exists("DocType", doctype):
            if not hasattr(copy_child_table, "_logged_missing_doctypes"):
                copy_child_table._logged_missing_doctypes = set()
            if doctype not in copy_child_table._logged_missing_doctypes:
                print(f"DocType {doctype} not found for {table_field}. Skipping.")
                copy_child_table._logged_missing_doctypes.add(doctype)
            return

        meta = frappe.get_meta(doctype)
        valid_columns = meta.get_valid_columns()
        copied_rows = [
            {k: getattr(row, k) for k in valid_columns if hasattr(row, k)}
            for row in source_rows
        ]
        target.set(table_field, copied_rows)
        print(f"Copied {len(copied_rows)} rows for {table_field} to {target.name}")
    except Exception as e:
        print(f"Error copying {table_field} for {source.name}: {str(e)}")

# Helper function to validate item before insertion
def validate_item(doc):
    """Validate required fields for an item."""
    required_fields = {
        "item_code": doc.item_code,
        "item_name": doc.item_name,
        "item_group": doc.item_group,
        "stock_uom": doc.stock_uom
    }
    for field, value in required_fields.items():
        if not value:
            raise frappe.ValidationError(f"Missing required field {field} for {doc.name or doc.item_code}")

# Helper function to create a new template item
def create_new_template(original_template, platform, active, shop=None):
    """
    Create a new template item based on original template for a specific platform and shop.
    
    Args:
        original_template: The original template Item document
        platform: The platform name (e.g. "Tiktok Shop", "Lazada")
        active: Boolean indicating if the template should be active
        shop: Optional shop name to include in the new item code
        
    Returns:
        The newly created template Item document
    """
    suffix = f"{platform}"
    if shop:
        suffix = f"{platform}-{shop}"
        
    print(f"Creating new template for {original_template.item_code} in {platform} - Shop: {shop}")
    
    new_item_code = f"{original_template.item_code}-{suffix}"
    # Ensure unique item_code
    counter = 1
    base_item_code = new_item_code
    while frappe.db.exists("Item", new_item_code):
        new_item_code = f"{base_item_code}-{counter}"
        counter += 1

    # Chuẩn bị marketplace variant data
    marketplace_variant_data = {
        "platform": platform,
        "active": active
    }
    
    # Chỉ thêm shop nếu có giá trị
    if shop:
        marketplace_variant_data["shop"] = shop

    new_template = frappe.new_doc("Item")
    new_template.update({
        "item_code": new_item_code,
        "item_name": original_template.item_name or original_template.item_code,
        "item_group": original_template.item_group or "All Item Groups",
        "stock_uom": original_template.stock_uom or "Nos",
        "is_stock_item": original_template.is_stock_item,
        "description": original_template.description or original_template.item_name,
        "brand": original_template.brand,
        "custom_has_sync_to_other_platform": 1,
        "custom_marketplace_source": platform,
        "custom_marketplace_variant": [marketplace_variant_data],
        "has_variants": 1,
        "attributes": original_template.attributes or [],
        # Thêm trường custom_parent_item để theo dõi item gốc
        "custom_parent_item": original_template.name,
        # Copy image fields if they exist
        "custom_image_item_1": getattr(original_template, "custom_image_item_1", None),
        "custom_attach_image": getattr(original_template, "custom_attach_image", None),
        "custom_image_item_2": getattr(original_template, "custom_image_item_2", None),
        "custom_attach_image_2": getattr(original_template, "custom_attach_image_2", None),
        "custom_image_item_3": getattr(original_template, "custom_image_item_3", None),
        "custom_attach_image_3": getattr(original_template, "custom_attach_image_3", None),
        "custom_image_item_4": getattr(original_template, "custom_image_item_4", None),
        "custom_attach_image_4": getattr(original_template, "custom_attach_image_4", None),
        "custom_image_item_5": getattr(original_template, "custom_image_item_5", None),
        "custom_attach_image_5": getattr(original_template, "custom_attach_image_5", None),
        # 360 Image fields
        "custom_360_image_1": getattr(original_template, "custom_360_image_1", None),
        "custom_attach_360_image_1": getattr(original_template, "custom_attach_360_image_1", None),
        "custom_360_image_2": getattr(original_template, "custom_360_image_2", None),
        "custom_attach_360_image_2": getattr(original_template, "custom_attach_360_image_2", None),
        "custom_360_image_3": getattr(original_template, "custom_360_image_3", None),
        "custom_attach_360_image_3": getattr(original_template, "custom_attach_360_image_3", None),
        "custom_360_image_4": getattr(original_template, "custom_360_image_4", None),
        "custom_attach_360_image_4": getattr(original_template, "custom_attach_360_image_4", None),
        "custom_360_image_5": getattr(original_template, "custom_360_image_5", None),
        "custom_attach_360_image_5": getattr(original_template, "custom_attach_360_image_5", None),
        "custom_360_image_6": getattr(original_template, "custom_360_image_6", None),
        "custom_attach_360_image_6": getattr(original_template, "custom_attach_360_image_6", None),
        "custom_360_image_7": getattr(original_template, "custom_360_image_7", None),
        "custom_attach_360_image_7": getattr(original_template, "custom_attach_360_image_7", None),
        "custom_360_image_8": getattr(original_template, "custom_360_image_8", None),
        "custom_attach_360_image_8": getattr(original_template, "custom_attach_360_image_8", None),
        # Specification
        "custom_specification_template": getattr(original_template, "custom_specification_template", None),
    })

    # Copy child tables
    copy_child_table(original_template, new_template, "custom_item_specification")
    
    # Clean attributes before saving
    clean_duplicate_attributes(new_template)
    
    # Validate before insertion
    validate_item(new_template)
    
    try:
        new_template.insert()
        frappe.db.commit()
        print(f"Successfully created template {new_template.name} with {len(new_template.attributes)} attributes")
        return new_template
    except Exception as e:
        frappe.db.rollback()
        print(f"Failed to create template {new_item_code}: {str(e)}")
        raise

# Helper function to create a new variant item
def create_new_variant(new_template, original_variant, platform, active, shop=None):
    """
    Create a new variant item based on original variant for a specific platform and shop.
    
    Args:
        new_template: The new template Item document this variant belongs to
        original_variant: The original variant Item document
        platform: The platform name (e.g. "Tiktok Shop", "Lazada")
        active: Boolean indicating if the variant should be active
        shop: Optional shop name to include in the new item code
        
    Returns:
        The newly created variant Item document
    """
    suffix = f"{platform}"
    if shop:
        suffix = f"{platform}-{shop}"
        
    print(f"Creating new variant for {original_variant.item_code} in {platform} - Shop: {shop}")
    
    new_item_code = f"{original_variant.item_code}-{suffix}"
    # Ensure unique item_code
    counter = 1
    base_item_code = new_item_code
    while frappe.db.exists("Item", new_item_code):
        new_item_code = f"{base_item_code}-{counter}"
        counter += 1

    # Chuẩn bị marketplace variant data
    marketplace_variant_data = {
        "platform": platform,
        "active": active
    }
    
    # Chỉ thêm shop nếu có giá trị
    if shop:
        marketplace_variant_data["shop"] = shop
        
    new_variant = frappe.new_doc("Item")
    new_variant.update({
        "item_code": new_item_code,
        "item_name": original_variant.item_name or original_variant.item_code,
        "item_group": original_variant.item_group or new_template.item_group,
        "stock_uom": original_variant.stock_uom or new_template.stock_uom,
        "is_stock_item": original_variant.is_stock_item,
        "description": original_variant.description or original_variant.item_name,
        "brand": original_variant.brand,
        "custom_has_sync_to_other_platform": 1,
        "custom_marketplace_source": platform,
        "custom_marketplace_variant": [marketplace_variant_data],
        "variant_of": new_template.name,
        "attributes": original_variant.attributes or [],
        # Thêm trường custom_parent_item để theo dõi item gốc
        "custom_parent_item": original_variant.name,
        # Copy image fields if they exist
        "custom_image_item_1": getattr(original_variant, "custom_image_item_1", None),
        "custom_attach_image": getattr(original_variant, "custom_attach_image", None),
        "custom_image_item_2": getattr(original_variant, "custom_image_item_2", None),
        "custom_attach_image_2": getattr(original_variant, "custom_attach_image_2", None),
        "custom_image_item_3": getattr(original_variant, "custom_image_item_3", None),
        "custom_attach_image_3": getattr(original_variant, "custom_attach_image_3", None),
        "custom_image_item_4": getattr(original_variant, "custom_image_item_4", None),
        "custom_attach_image_4": getattr(original_variant, "custom_attach_image_4", None),
        "custom_image_item_5": getattr(original_variant, "custom_image_item_5", None),
        "custom_attach_image_5": getattr(original_variant, "custom_attach_image_5", None),
        # 360 Image fields
        "custom_360_image_1": getattr(original_variant, "custom_360_image_1", None),
        "custom_attach_360_image_1": getattr(original_variant, "custom_attach_360_image_1", None),
        "custom_360_image_2": getattr(original_variant, "custom_360_image_2", None),
        "custom_attach_360_image_2": getattr(original_variant, "custom_attach_360_image_2", None),
        "custom_360_image_3": getattr(original_variant, "custom_360_image_3", None),
        "custom_attach_360_image_3": getattr(original_variant, "custom_attach_360_image_3", None),
        "custom_360_image_4": getattr(original_variant, "custom_360_image_4", None),
        "custom_attach_360_image_4": getattr(original_variant, "custom_attach_360_image_4", None),
        "custom_360_image_5": getattr(original_variant, "custom_360_image_5", None),
        "custom_attach_360_image_5": getattr(original_variant, "custom_attach_360_image_5", None),
        "custom_360_image_6": getattr(original_variant, "custom_360_image_6", None),
        "custom_attach_360_image_6": getattr(original_variant, "custom_attach_360_image_6", None),
        "custom_360_image_7": getattr(original_variant, "custom_360_image_7", None),
        "custom_attach_360_image_7": getattr(original_variant, "custom_attach_360_image_7", None),
        "custom_360_image_8": getattr(original_variant, "custom_360_image_8", None),
        "custom_attach_360_image_8": getattr(original_variant, "custom_attach_360_image_8", None),
        # Specification
        "custom_specification_template": getattr(original_variant, "custom_specification_template", None),
    })

    # Copy child tables
    copy_child_table(original_variant, new_variant, "custom_item_specification")
    
    # Clean attributes before saving
    clean_duplicate_attributes(new_variant)
    
    # Validate before insertion
    validate_item(new_variant)
    
    try:
        new_variant.insert()
        frappe.db.commit()
        print(f"Successfully created variant {new_variant.name} with {len(new_variant.attributes)} attributes")
        return new_variant
    except Exception as e:
        frappe.db.rollback()
        print(f"Failed to create variant {new_item_code}: {str(e)}")
        raise

@frappe.whitelist()
def flatten_variants_to_items(item_code):
    """
    Flatten an Item and its variants into new Items for each marketplace in custom_marketplace_variant.
    Creates new template and variant items with the same active status as in the original marketplace variant.
    Mỗi item mới được tạo sẽ có trường custom_parent_item trỏ tới item gốc.
    
    Args:
        item_code: The item code of the template to flatten
        
    Returns:
        Dict with success status, created items, and messages
    """
    try:
        print(f"Flattening variants for item_code: {item_code}")
        template = frappe.get_doc("Item", item_code)
        
        # Validate template
        if not template.has_variants:
            print(f"Item {item_code} is not a template with variants.")
            return {"success": False, "error": "Item is not a template with variants."}

        if not template.custom_marketplace_variant:
            print(f"No marketplace variants found for {item_code}")
            return {"success": False, "error": "No marketplace variants defined for this item."}

        created_items = {"templates": [], "variants": []}
        active_marketplace_variants = [v for v in template.custom_marketplace_variant or [] if v.active]
        
        print(f"Found {len(active_marketplace_variants)} active marketplace variants")
        
        if not active_marketplace_variants:
            return {"success": False, "error": "No active marketplace variants found."}

        # Get variants of the template
        variants = frappe.get_all("Item", filters={"variant_of": template.name}, fields=["name"])
        if not variants:
            print(f"No variants found for template {template.name}.")
            return {"success": False, "error": "No variants found for this template."}
        
        print(f"Found {len(variants)} variants for template {template.name}")

        # Process each active marketplace variant
        for variant in active_marketplace_variants:
            platform = variant.platform
            # Sử dụng getattr để kiểm tra an toàn nếu không có thuộc tính shop
            shop = getattr(variant, 'shop', None)
            active = variant.active
            
            print(f"Processing platform: {platform}, shop: {shop}, active: {active}")
            
            # Create new template for this marketplace and shop
            new_template = create_new_template(template, platform, active, shop)
            created_items["templates"].append(new_template.name)
            
            print(f"Created new template {new_template.name} with custom_parent_item={template.name}")
            
            # Copy marketplace mapping if it exists
            mapping_filters = {
                "marketplace": platform,
            }
            
            # Chỉ thêm shop vào filter nếu có giá trị
            if shop:
                mapping_filters["shop"] = shop
                
            marketplace_mapping = next(
                (m for m in (template.custom_marketplace_item_mapping or []) 
                 if m.marketplace == platform and 
                 (not hasattr(m, 'shop') or not m.shop or 
                  getattr(m, 'shop', None) == shop)),
                None
            )
            
            if marketplace_mapping:
                try:
                    # Chuẩn bị marketplace mapping data
                    mapping_data = {
                        "marketplace": platform,
                        "marketplace_product_id": getattr(marketplace_mapping, "marketplace_product_id", None),
                        "marketplace_sku_id": getattr(marketplace_mapping, "marketplace_sku_id", None),
                        "marketplace_sku": getattr(marketplace_mapping, "marketplace_sku", None),
                        "last_sync_time": getattr(marketplace_mapping, "last_sync_time", None),
                        "sync_status": getattr(marketplace_mapping, "sync_status", None),
                        "active": getattr(marketplace_mapping, "active", False)
                    }
                    
                    # Chỉ thêm shop nếu có
                    if shop:
                        mapping_data["shop"] = shop
                        
                    new_template.append("custom_marketplace_item_mapping", mapping_data)
                    new_template.save()
                    frappe.db.commit()
                    print(f"Copied marketplace mapping for {new_template.name}: {platform}")
                except Exception as e:
                    print(f"Failed to copy marketplace mapping for {new_template.name}: {str(e)}")
            
            # Create variants for the new template
            for variant_item in variants:
                variant_doc = frappe.get_doc("Item", variant_item.name)
                new_variant = create_new_variant(new_template, variant_doc, platform, active, shop)
                created_items["variants"].append(new_variant.name)
                
                print(f"Created new variant {new_variant.name} with custom_parent_item={variant_doc.name}")
                
                # Copy marketplace mapping for the variant if it exists
                variant_mapping = next(
                    (m for m in (variant_doc.custom_marketplace_item_mapping or []) 
                     if m.marketplace == platform and 
                     (not hasattr(m, 'shop') or not m.shop or 
                      getattr(m, 'shop', None) == shop)),
                    None
                )
                
                if variant_mapping:
                    try:
                        # Chuẩn bị variant mapping data
                        variant_mapping_data = {
                            "marketplace": platform,
                            "marketplace_product_id": getattr(variant_mapping, "marketplace_product_id", None),
                            "marketplace_sku_id": getattr(variant_mapping, "marketplace_sku_id", None),
                            "marketplace_sku": getattr(variant_mapping, "marketplace_sku", None),
                            "last_sync_time": getattr(variant_mapping, "last_sync_time", None),
                            "sync_status": getattr(variant_mapping, "sync_status", None),
                            "active": getattr(variant_mapping, "active", False)
                        }
                        
                        # Chỉ thêm shop nếu có
                        if shop:
                            variant_mapping_data["shop"] = shop
                            
                        new_variant.append("custom_marketplace_item_mapping", variant_mapping_data)
                        new_variant.save()
                        frappe.db.commit()
                        print(f"Copied marketplace mapping for {new_variant.name}")
                    except Exception as e:
                        print(f"Failed to copy marketplace mapping for {new_variant.name}: {str(e)}")

        # Verify all expected items were created
        expected_templates = len(active_marketplace_variants)
        expected_variants = len(active_marketplace_variants) * len(variants)
        actual_templates = len(created_items["templates"])
        actual_variants = len(created_items["variants"])
        
        if actual_templates != expected_templates or actual_variants != expected_variants:
            error_msg = (
                f"Incomplete flattening: Expected {expected_templates} templates and {expected_variants} variants, "
                f"but created {actual_templates} templates and {actual_variants} variants."
            )
            print(error_msg)
            return {
                "success": False,
                "error": error_msg,
                "created_items": created_items
            }
        
        print(f"Completed flattening. Created {actual_templates} templates and {actual_variants} variants with custom_parent_item references")
        return {
            "success": True,
            "created_items": created_items,
            "message": f"Created {actual_templates} templates and {actual_variants} variants successfully with parent references"
        }
    
    except Exception as e:
        error_message = str(e)
        print(f"Error flattening variants for {item_code}: {error_message}")
        frappe.log_error(f"Error flattening variants for {item_code}: {error_message}")
        return {
            "success": False, 
            "error": error_message, 
            "created_items": created_items if 'created_items' in locals() else {}
        }