# Trong /workspace/development/frappe-bench/apps/sync_product_data/sync_product_data/item_group.py

from erpnext.setup.doctype.item_group.item_group import ItemGroup as BaseItemGroup
import frappe
from frappe import _
from sync_product_data.sync_product_data.tiktok_integration.utils import get_tiktok_api
from sync_product_data.sync_product_data.tiktok_integration.tiktok_attribute_sync import sync_tiktok_attributes
from spec.spec.lazada.lazada_attributes import get_category_attributes, sync_lazada_attributes, update_marketplace_attribute

class ItemGroup(BaseItemGroup):
    """
    Mở rộng class ItemGroup để xử lý việc đồng bộ dữ liệu với các sàn thương mại điện tử
    """
    
    def before_save(self):
        """
        Xử lý trước khi lưu Item Group:
        1. Kiểm tra nếu có thay đổi trong danh mục sàn thương mại
        2. Đồng bộ thuộc tính từ các sàn cho mỗi danh mục
        """
        # Kiểm tra xem có phải là bản ghi mới hoặc đã được cập nhật không
        if not self.is_new() and not self.has_value_changed("custom_ecommerce_platform"):
            return
            
        # Lấy danh sách các danh mục từ các sàn
        marketplace_categories = {
            "Lazada": [],
            "TikTok Shop": []
        }
        
        for category in self.custom_ecommerce_platform or []:
            if category.ecommerce_platform in marketplace_categories and category.marketplace_category:
                marketplace_categories[category.ecommerce_platform].append({
                    "marketplace_category": category.marketplace_category,
                    "category_name": category.category_name
                })
        
        # Xử lý cho từng sàn
        for platform, categories in marketplace_categories.items():
            if not categories:
                continue
                
            if platform == "Lazada":
                self._process_lazada_categories(categories)
            elif platform == "TikTok Shop":
                self._process_tiktok_categories(categories)
    
    def on_update(self):
        """
        Xử lý sau khi cập nhật Item Group:
        1. Gọi phương thức gốc on_update
        2. Đồng bộ thuộc tính với các sàn thương mại điện tử
        """
        super().on_update()
        
        if not self.custom_ecommerce_platform:
            print(f"No ecommerce platforms defined for Item Group {self.name}")
            return

        self._sync_attributes_with_platforms()
    
    def _sync_attributes_with_platforms(self):
        """
        Đồng bộ thuộc tính với từng sàn thương mại điện tử
        """
        print(f"Item Group {self.name} updated. Syncing attributes to marketplaces.")
        
        # Duyệt qua từng dòng trong bảng custom_ecommerce_platform
        for platform in self.custom_ecommerce_platform or []:
            if not platform.marketplace_category:
                print(f"No marketplace category defined for {platform.ecommerce_platform}")
                continue

            category_id = frappe.db.get_value("Marketplace Category", platform.marketplace_category, "category_id")
            if not category_id:
                print(f"No category_id found for {platform.marketplace_category} in {platform.ecommerce_platform}")
                continue

            # Xử lý theo từng loại sàn
            self._sync_platform_attributes(platform.ecommerce_platform, category_id)
    
    def _sync_platform_attributes(self, platform_name, category_id):
        """
        Đồng bộ thuộc tính với một sàn cụ thể
        
        Args:
            platform_name (str): Tên sàn (Tiktok Shop, Lazada,...)
            category_id (str): ID danh mục trên sàn
        """
        if platform_name == "Tiktok Shop":
            self._sync_tiktok_attributes(category_id)
        elif platform_name == "Lazada":
            print(f"Lazada attribute sync for {self.name} not implemented yet")
        else:
            print(f"Unsupported platform: {platform_name}. No attribute sync implemented.")
    
    def _sync_tiktok_attributes(self, category_id):
        """
        Đồng bộ thuộc tính với TikTok Shop
        
        Args:
            category_id (str): ID danh mục trên TikTok Shop
        """
        api_doc = get_tiktok_api()
        if not api_doc:
            frappe.msgprint("Không thể lấy thông tin TikTok Shop API")
            return

        print(f"Queueing attribute sync for TikTok Shop category {category_id}")
        frappe.enqueue(
            "sync_product_data.sync_product_data.tiktok_integration.tiktok_attribute_sync.sync_tiktok_attributes",
            queue="short",
            timeout=20,
            item_group_doc=self,
            category_id=category_id,
            api_doc=api_doc
        )
    
    def _process_lazada_categories(self, categories):
        """
        Xử lý đồng bộ thuộc tính từ Lazada
        
        Args:
            categories (list): Danh sách các danh mục Lazada
        """
        for category in categories:
            try:
                # Lấy category_id từ marketplace_category
                category_id = frappe.db.get_value("Marketplace Category", category["marketplace_category"], "category_id")
                if not category_id:
                    frappe.log_error(
                        f"Không tìm thấy category_id cho {category['marketplace_category']}", 
                        "Lazada Attribute Sync"
                    )
                    continue
                
                # Lấy danh sách thuộc tính từ Lazada
                attributes = get_category_attributes(category_id)
                if not attributes:
                    frappe.log_error(
                        f"Không tìm thấy thuộc tính cho danh mục {category_id}", 
                        "Lazada Attribute Sync"
                    )
                    continue
                
                # Cập nhật thuộc tính vào Marketplace Attribute
                for attr in attributes:
                    update_marketplace_attribute(attr)
                
                frappe.msgprint(f"Đã đồng bộ thuộc tính cho danh mục Lazada: {category['category_name']}")
                
            except Exception as e:
                frappe.log_error(
                    f"Lỗi khi đồng bộ thuộc tính cho danh mục {category['category_name']}: {str(e)[:100]}", 
                    "Lazada Attribute Sync"
                )
    
    def _process_tiktok_categories(self, categories):
        """
        Xử lý đồng bộ thuộc tính từ TikTok Shop
        
        Args:
            categories (list): Danh sách các danh mục TikTok Shop
        """
        # TODO: Implement TikTok Shop attribute sync
        frappe.msgprint("Tính năng đồng bộ thuộc tính từ TikTok Shop chưa được triển khai")


def create_item_attributes(item_group, attributes):
    """
    Tạo Item Attribute từ danh sách thuộc tính và thêm bảng con Item Attribute Marketplace Mapping
    
    Args:
        item_group (str): Tên của Item Group
        attributes (list): Danh sách thuộc tính từ marketplace
    """
    try:
        # Kiểm tra xem Item Group đã có Item Attribute chưa
        existing_attributes = frappe.get_all(
            "Item Attribute",
            filters={"item_group": item_group},
            fields=["attribute"]
        )
        existing_attribute_names = [attr.attribute for attr in existing_attributes]
        
        # Tạo Item Attribute cho các thuộc tính mới
        for attr in attributes:
            attribute_name = attr.get("name")
            if not attribute_name or attribute_name in existing_attribute_names:
                continue
                
            # Tạo Item Attribute mới
            item_attr = frappe.get_doc({
                "doctype": "Item Attribute",
                "item_group": item_group,
                "attribute": attribute_name,
                "from_range": 0,
                "increment": 0,
                "numeric_values": 0,
                "to_range": 0
            })
            
            # Thêm Item Attribute Value cho các giá trị có sẵn
            if attr.get("values"):
                for value in attr.get("values"):
                    value_name = value.get("name")
                    if not value_name:
                        continue
                        
                    item_attr.append("item_attribute_values", {
                        "attribute_value": value_name,
                        "abbr": value_name[:10]  # Sử dụng 10 ký tự đầu tiên làm abbr
                    })
            
            # Lưu Item Attribute
            item_attr.insert(ignore_permissions=True)
            
            # Tìm Marketplace Attribute tương ứng
            marketplace_attr = frappe.get_all(
                "Marketplace Attribute",
                filters={
                    "marketplace": attr.get("marketplace", "Lazada"),
                    "attribute_id": attr.get("id")
                },
                fields=["name", "attribute_name"],
                limit=1
            )
            
            if marketplace_attr:
                # Tạo Item Attribute Marketplace Mapping
                mapping = frappe.get_doc({
                    "doctype": "Item Attribute Marketplace Mapping",
                    "marketplace": attr.get("marketplace", "Lazada"),
                    "marketplace_attribute": marketplace_attr[0].name,
                    "attribute_name": marketplace_attr[0].attribute_name
                })
                
                # Thêm mapping vào Item Attribute
                item_attr.append("item_attribute_marketplace_mapping", mapping.as_dict())
                item_attr.save(ignore_permissions=True)
        
        frappe.db.commit()
        return True
        
    except Exception as e:
        frappe.log_error(
            f"Lỗi khi tạo Item Attribute cho {item_group}: {str(e)[:100]}", 
            "Marketplace Attribute Sync"
        )
        return False