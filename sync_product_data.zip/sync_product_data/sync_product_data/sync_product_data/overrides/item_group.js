frappe.ui.form.on("Item Group", {
    refresh: function(frm) {
        // Thêm xử lý blur event cho item_group_name
        frm.fields_dict.item_group_name.$input.on('blur', function() {
            if (this.value && this.value !== frm.doc._previous_item_group_name) {
                frm.doc._previous_item_group_name = this.value;
                handle_category_suggestions(frm);
            }
        });

        // Tùy chỉnh style và hiển thị cho trường marketplace_category
        enhance_marketplace_category_field(frm);
        
        // Lọc "marketplace_category" dựa theo "ecommerce_platform" và is_group=0
        frm.fields_dict["custom_ecommerce_platform"].grid.get_field("marketplace_category").get_query = function(doc, cdt, cdn) {
            let row = frappe.get_doc(cdt, cdn);
            
            console.log("Getting marketplace_category query with filters:", {
                "marketplace": row.ecommerce_platform,
                "is_group": 0
            });
            
            return {
                filters: {
                    // so khớp "marketplace" bên Marketplace Category
                    // với "ecommerce_platform" người dùng chọn
                    "marketplace": row.ecommerce_platform,
                    // chỉ trả về node lá
                    "is_group": 0
                }
            };
        };
    },

    validate: function(frm) {
        console.log("Item Group form validating!");
        // Kiểm tra trùng lặp khi lưu form
        validate_no_duplicate_platforms(frm);
    }
});

// Xử lý cập nhật các trường trong child table Item Group Category
frappe.ui.form.on("Item Group Category", {
    ecommerce_platform: function(frm, cdt, cdn) {
        let row = frappe.get_doc(cdt, cdn);
        
        // Nếu đã chọn Lazada và có item_group_name, tự động gọi API để lấy category
        if (row.ecommerce_platform === 'Lazada' && frm.doc.item_group_name) {
            console.log("Đã chọn Lazada, tự động lấy category cho:", frm.doc.item_group_name);
            handle_category_suggestions(frm);
        }

        // Kiểm tra trùng lặp ngay khi chọn ecommerce_platform
        if (validate_no_duplicate_platforms(frm, cdt, cdn)) {
            // Reset các trường khi đổi platform
            frappe.model.set_value(cdt, cdn, "marketplace_category", null);
            frappe.model.set_value(cdt, cdn, "category_name", null);
        }
    },

    marketplace_category: function(frm, cdt, cdn) {
        let row = frappe.get_doc(cdt, cdn);
        if (!row.marketplace_category) return;

        frappe.db.get_value("Marketplace Category", row.marketplace_category, "category_name")
        .then(r => {
            if (r.message) {
                frappe.model.set_value(cdt, cdn, "category_name", r.message.category_name);
            }
        });
    }
});

/**
 * Tăng cường hiển thị trường marketplace_category
 * @param {Object} frm - Form Item Group
 */
function enhance_marketplace_category_field(frm) {
    // Tùy chỉnh style cho dropdown Market Category
    frm.fields_dict["custom_ecommerce_platform"].grid.wrapper.find('.frappe-control[data-fieldname="marketplace_category"]').css({
        'min-width': '400px',
        'max-width': 'none',
        'white-space': 'nowrap',
        'overflow': 'visible'
    });

    // Tùy chỉnh hiển thị cho marketplace_category field
    let marketplace_field = frm.fields_dict["custom_ecommerce_platform"].grid.get_field("marketplace_category");
    
    // Tùy chỉnh formatter để hiển thị đầy đủ nội dung
    marketplace_field.formatter = function(value, df, options, row) {
        if (!value) return "";
        return `<div class="full-width-text">${value}</div>`;
    };

    // Thêm style vào head
    if (!document.getElementById('marketplace-category-style')) {
        const style = document.createElement('style');
        style.id = 'marketplace-category-style';
        style.textContent = `
            .full-width-text {
                width: 100%;
                white-space: normal;
                word-break: break-word;
            }
            .awesomplete > ul {
                min-width: 100%;
                width: auto !important;
                white-space: normal;
                word-break: break-word;
            }
            .awesomplete > ul > li {
                white-space: normal;
                word-break: break-word;
                padding: 5px;
                line-height: 1.4;
            }
            .grid-static-col[data-fieldname="marketplace_category"],
            .form-grid .grid-row .grid-cell[data-fieldname="marketplace_category"] {
                width: 300px !important;
                max-width: none !important;
            }
        `;
        document.head.appendChild(style);
    }

    // Điều chỉnh chiều rộng cột trong grid
    frm.fields_dict["custom_ecommerce_platform"].grid.gridrow.columns.marketplace_category.df.width = 300;
    frm.fields_dict["custom_ecommerce_platform"].grid.refresh();

    // Tùy chỉnh style cho dropdown options
    setTimeout(() => {
        $('.awesomplete ul').css({
            'min-width': '400px',
            'max-width': 'none',
            'white-space': 'nowrap'
        });
    }, 1000);
}

/**
 * Kiểm tra không có sàn trùng lặp trong bảng custom_ecommerce_platform
 * @param {Object} frm - Form Item Group
 * @param {String} cdt - Child DocType (tùy chọn)
 * @param {String} cdn - Child DocName (tùy chọn)
 * @returns {Boolean} - True nếu không có trùng lặp, False nếu có trùng lặp
 */
function validate_no_duplicate_platforms(frm, cdt = null, cdn = null) {
    let seen_platforms = [];
    let current_row = cdt && cdn ? frappe.get_doc(cdt, cdn) : null;
    
    // Kiểm tra trùng lặp
    for (let row of frm.doc.custom_ecommerce_platform || []) {
        if (!row.ecommerce_platform) continue;
        
        if (seen_platforms.includes(row.ecommerce_platform)) {
            let message = __("Không thể trùng sàn: {0}. Mỗi sàn chỉ được chọn 1 lần.", [row.ecommerce_platform]);
            
            // Nếu đang xử lý sự kiện trên một hàng cụ thể
            if (current_row && row.name === current_row.name) {
                frappe.msgprint(message);
                frappe.model.set_value(cdt, cdn, "ecommerce_platform", null);
                return false;
            } else if (!current_row) {
                // Nếu đang validate form
                frappe.throw(message);
                return false;
            }
        }
        
        seen_platforms.push(row.ecommerce_platform);
    }
    
    return true;
}

/**
 * Xử lý gợi ý danh mục cho Item Group dựa trên tên
 * @param {Object} frm - Form Item Group
 */
function handle_category_suggestions(frm) {
    if (!frm.doc.item_group_name) return;

    console.log("Đang gọi API get_category_suggestions với keyword:", frm.doc.item_group_name);

    // Gọi API get_category_suggestions
    frappe.call({
        method: 'spec.spec.lazada.lazada_category.get_category_suggestions',
        args: {
            'item_name': frm.doc.item_group_name
        },
        callback: function(response) {
            console.log("Response từ API:", response);

            if (!response.message) {
                console.log("Không có response.message");
                frappe.show_alert({
                    message: __('Không nhận được phản hồi từ API'),
                    indicator: 'red'
                });
                return;
            }

            // Kiểm tra cấu trúc của response
            let category = response.message.lines;
            console.log("Category:", category);

            if (!category || !category.category_id) {
                console.log("Không có category");
                frappe.show_alert({
                    message: __('Không tìm thấy category phù hợp cho item group này'),
                    indicator: 'orange'
                });
                return;
            }

            console.log("Selected category:", category);

            // Kiểm tra xem đã có Lazada platform chưa
            let existing_lazada_row = null;
            if (frm.doc.custom_ecommerce_platform) {
                existing_lazada_row = frm.doc.custom_ecommerce_platform.find(row => 
                    row.ecommerce_platform === 'Lazada'
                );
            }

            // Tìm Marketplace Category tương ứng
            frappe.db.get_list('Marketplace Category', {
                filters: {
                    'category_id': category.category_id,
                    'marketplace': 'Lazada'
                },
                fields: ['name', 'category_name']
            }).then(result => {
                console.log("Marketplace Category result:", result);

                if (result && result.length > 0) {
                    let marketplace_category = result[0];
                    console.log("Found Marketplace Category:", marketplace_category);

                    if (existing_lazada_row) {
                        console.log("Cập nhật row Lazada hiện có");
                        // Nếu đã có row Lazada, cập nhật category
                        frappe.model.set_value(
                            existing_lazada_row.doctype,
                            existing_lazada_row.name,
                            'marketplace_category',
                            marketplace_category.name
                        );
                    } else {
                        console.log("Tạo mới row Lazada");
                        // Nếu chưa có, tạo mới row cho Lazada
                        let child = frm.add_child('custom_ecommerce_platform');
                        frappe.model.set_value(child.doctype, child.name, {
                            'ecommerce_platform': 'Lazada',
                            'marketplace_category': marketplace_category.name
                        });
                    }
                    
                    // Refresh lại grid
                    frm.refresh_field('custom_ecommerce_platform');

                    // Hiển thị thông báo thành công
                    frappe.show_alert({
                        message: __('Đã tự động thêm category Lazada: {0}', [marketplace_category.category_name]),
                        indicator: 'green'
                    });
                } else {
                    console.log("Không tìm thấy Marketplace Category cho category_id:", category.category_id);
                    // Tạo Marketplace Category mới
                    frappe.call({
                        method: 'frappe.client.insert',
                        args: {
                            doc: {
                                doctype: 'Marketplace Category',
                                category_id: category.category_id,
                                category_name: category.category_name,
                                marketplace: 'Lazada',
                                is_group: 0
                            }
                        },
                        callback: function(r) {
                            if (r.message) {
                                console.log("Đã tạo Marketplace Category mới:", r.message);
                                // Thêm vào custom_ecommerce_platform
                                if (existing_lazada_row) {
                                    frappe.model.set_value(
                                        existing_lazada_row.doctype,
                                        existing_lazada_row.name,
                                        'marketplace_category',
                                        r.message.name
                                    );
                                } else {
                                    let child = frm.add_child('custom_ecommerce_platform');
                                    frappe.model.set_value(child.doctype, child.name, {
                                        'ecommerce_platform': 'Lazada',
                                        'marketplace_category': r.message.name
                                    });
                                }
                                frm.refresh_field('custom_ecommerce_platform');
                                frappe.show_alert({
                                    message: __('Đã tạo và thêm category Lazada mới: {0}', [category.category_name]),
                                    indicator: 'green'
                                });
                            }
                        }
                    });
                }
            }).catch(err => {   
                console.error("Lỗi khi tìm Marketplace Category:", err);
                frappe.show_alert({ 
                    message: __('Lỗi khi tìm Marketplace Category: {0}', [err.message]),
                    indicator: 'red'
                });
            });
        }
    });
}

