import frappe
from sync_product_data.sync_product_data.tiktok_integration.tiktok_shop_api import create_tiktok_product, update_tiktok_product, delete_tiktok_product
from sync_product_data.sync_product_data.tiktok_integration.utils import get_tiktok_category_id, upload_image
from sync_product_data.sync_product_data.tiktok_integration.tiktok_category_sync import get_category_rules, validate_category_rules

def update_or_create_tiktok_shop(**kwargs):
    """Đồng bộ sản phẩm lên TikTok Shop (tạo mới hoặc cập nhật)."""
    inner_kwargs = kwargs.get("kwargs", {})
    item_doc = inner_kwargs.get("item_doc")

    # Tải lại item_doc từ database để tránh xung đột
    item_doc = frappe.get_doc("Item", item_doc.name)

    # Tìm mapping trong child table
    tiktok_mapping = next(
        (m for m in (item_doc.custom_marketplace_item_mapping or []) if m.marketplace == "TikTok" and m.active),
        None
    )
    print(f"Mapping for {item_doc.name}: {tiktok_mapping}")

    product_data = prepare_product_data_tiktok_shop(item_doc)
    if not product_data:
        print(f"Failed to prepare product data for {item_doc.name}")
        return

    if not tiktok_mapping:
        print(f"Creating new TikTok Product for {item_doc.name}")
        response = create_tiktok_product(product_data)
        if response and response.get("code") == 0:
            tiktok_product_id = response.get("data", {}).get("product_id")
            if tiktok_product_id:
                frappe.db.append("Item", item_doc.name, "custom_marketplace_item_mapping", {
                    "marketplace": "TikTok",
                    "marketplace_product_id": tiktok_product_id,
                    "marketplace_sku": product_data["skus"][0]["seller_sku"],
                    "last_sync_time": frappe.utils.now(),
                    "sync_status": "Success",  # Cập nhật thành Success
                    "active": 1
                })
                frappe.db.commit()
                print(f"Created TikTok Product {tiktok_product_id}")
            else:
                frappe.db.append("Item", item_doc.name, "custom_marketplace_item_mapping", {
                    "marketplace": "TikTok",
                    "marketplace_sku": product_data["skus"][0]["seller_sku"],
                    "last_sync_time": frappe.utils.now(),
                    "sync_status": "Failed",
                    "active": 1
                })
                frappe.db.commit()
        else:
            error_message = f"Failed to create TikTok Product: {response}"
            frappe.log_error(error_message)
            frappe.db.append("Item", item_doc.name, "custom_marketplace_item_mapping", {
                "marketplace": "TikTok",
                "marketplace_sku": product_data["skus"][0]["seller_sku"],
                "last_sync_time": frappe.utils.now(),
                "sync_status": "Failed",
                "active": 1
            })
            frappe.db.commit()
    else:
        print(f"Updating TikTok Product for {item_doc.name}")
        tiktok_product_id = tiktok_mapping.marketplace_product_id
        if not tiktok_product_id:
            print(f"No marketplace_product_id found for {item_doc.name}")
            return

        response = update_tiktok_product(tiktok_product_id, product_data)
        if response and response.get("code") == 0:
            print(f"Updated TikTok Product {tiktok_product_id}")
            frappe.db.set_value("Marketplace Item Mapping", tiktok_mapping.name, {
                "sync_status": "Success",  # Cập nhật thành Success
                "last_sync_time": frappe.utils.now()
            })
            frappe.db.commit()
            print(f"Successfully updated TikTok Product {tiktok_product_id}")
        else:
            error_message = f"Failed to update TikTok Product {tiktok_product_id}: {response}"
            frappe.log_error(error_message)
            frappe.db.set_value("Marketplace Item Mapping", tiktok_mapping.name, {
                "sync_status": "Failed",
                "last_sync_time": frappe.utils.now()
            })
            frappe.db.commit()

def delete_tiktok_product_api(tiktok_product_id):
    """Chỉ gọi API xóa sản phẩm trên TikTok Shop."""
    response = delete_tiktok_product(tiktok_product_id)
    if response and response.get("code") == 0:
        print(f"Successfully deleted TikTok Product {tiktok_product_id}")
    else:
        error_message = f"Failed to delete TikTok Product {tiktok_product_id}: {response}"
        print(error_message)
        frappe.log_error(error_message)

def delete_tiktok_shop(item_doc):
    """Xử lý toàn bộ logic xóa sản phẩm TikTok Shop."""
    print(f"Preparing to delete TikTok Shop product for {item_doc.name}")
    
    tiktok_mapping = next(
        (m for m in (item_doc.custom_marketplace_item_mapping or []) if m.marketplace == "TikTok" and m.active),
        None
    )
    print(f"Mapping for {item_doc.name}: {tiktok_mapping}")

    if not tiktok_mapping or not tiktok_mapping.marketplace_product_id:
        print(f"No TikTok Shop mapping found for {item_doc.name}. No action taken.")
        return

    # Xóa bản ghi trong child table
    frappe.db.delete("Marketplace Item Mapping", {"name": tiktok_mapping.name})
    frappe.db.commit()
    print(f"Deleted TikTok Shop mapping for {item_doc.name}")

    # Đẩy việc xóa trên TikTok Shop vào queue
    tiktok_product_id = tiktok_mapping.marketplace_product_id
    frappe.enqueue(
        "sync_product_data.sync_product_data.tiktok_integration.tiktok_product_sync.delete_tiktok_product_api",
        queue="short",
        timeout=20,
        tiktok_product_id=tiktok_product_id
    )
    print(f"Enqueued deletion of TikTok Product {tiktok_product_id} for {item_doc.name}")

# Hàm phụ trợ để chuẩn bị ảnh chính
def prepare_main_images(item, default_image_url="tos-maliva-i-o3syd03w52-us/ab2f4ec275cb4b949a2e626c3071596b"):
    main_images = []
    if item.image:
        main_image_uri = upload_image(item.image, use_case="MAIN_IMAGE") or default_image_url
        main_images.append({"uri": main_image_uri})
    else:
        main_images.append({"uri": default_image_url})
    return main_images

# Hàm phụ trợ chuẩn bị ảnh bổ sung
def prepare_additional_images(item):
    additional_images = []
    for i in range(1, 6):
        attach_field = f"custom_attach_image_{i}" if i > 1 else "custom_attach_image"
        if hasattr(item, attach_field) and getattr(item, attach_field):
            uri = upload_image(getattr(item, attach_field), use_case="DESCRIPTION_IMAGE") or None
            if uri:
                additional_images.append({"uri": uri})
    for i in range(1, 9):
        attach_field = f"custom_attach_360_image_{i}"
        if hasattr(item, attach_field) and getattr(item, attach_field) and len(additional_images) < 9:
            uri = upload_image(getattr(item, attach_field), use_case="DESCRIPTION_IMAGE") or None
            if uri:
                additional_images.append({"uri": uri})
    return additional_images[:9]

# Hàm phụ trợ chuẩn bị SKU
def prepare_skus(item, default_warehouse_id="7483552233957639941", default_currency="VND", default_image_url="tos-maliva-i-o3syd03w52-us/ab2f4ec275cb4b949a2e626c3071596b"):
    skus = []
    
    # Hàm phụ trợ để lấy giá từ Item Price
    def get_item_price(item_code, price_list="Standard Selling"):
        price_data = frappe.db.get_value(
            "Item Price",
            {
                "item_code": item_code,
                "price_list": price_list,
                "selling": 1
            },
            ["price_list_rate", "currency"]
        )
        if price_data:
            price, currency = price_data
            return price, currency
        return None, None

    if item.has_variants:
        variants = frappe.get_all(
            "Item",
            filters={"variant_of": item.item_code},
            fields=["item_code", "item_name", "opening_stock", "standard_rate", "image", "custom_attach_image"]
        )
        if not variants:
            print(f"Không tìm thấy biến thể cho sản phẩm {item.name}")
            return None

        sales_attrs = {}
        try:
            for attr in frappe.get_all("Item Attribute", fields=["name"]):
                attr_doc = frappe.get_doc("Item Attribute", attr["name"])
                mappings = attr_doc.get("custom_item_attribute_marketplace_mapping", [])
                for mapping in mappings:
                    if mapping.marketplace == "TikTok Shop":
                        marketplace_attr = frappe.get_doc("Marketplace Attribute", mapping.marketplace_attribute)
                        if marketplace_attr.type == "SALES_PROPERTY" and marketplace_attr.is_customizable:
                            sales_attrs[attr["name"]] = {
                                "id": marketplace_attr.attribute_id,
                                "name": marketplace_attr.attribute_name
                            }
        except Exception as e:
            print(f"Lỗi khi lấy mapping thuộc tính: {str(e)}")
            sales_attrs = {}

        sales_attrs = dict(list(sales_attrs.items())[:3])

        seen_combinations = set()
        for variant in variants:
            variant_attrs = frappe.get_all(
                "Item Variant Attribute",
                filters={"parent": variant["item_code"]},
                fields=["attribute", "attribute_value"]
            )
            
            sales_attributes = []
            for attr in variant_attrs:
                if attr["attribute"] in sales_attrs:
                    sales_attributes.append({
                        "id": sales_attrs[attr["attribute"]]["id"],
                        "name": sales_attrs[attr["attribute"]]["name"],
                        "value_name": attr["attribute_value"]
                    })

            if not sales_attributes:
                print(f"Không có thuộc tính bán hàng hợp lệ cho biến thể {variant['item_code']}")
                continue

            attr_key = tuple(sorted((attr["name"], attr["value_name"]) for attr in sales_attributes))
            if attr_key in seen_combinations:
                print(f"Tổ hợp thuộc tính trùng lặp {attr_key} cho biến thể {variant['item_code']}")
                continue
            seen_combinations.add(attr_key)

            sku_img_uri = default_image_url
            if variant["image"]:
                sku_img_uri = upload_image(variant["image"], use_case="ATTRIBUTE_IMAGE") or default_image_url
            elif variant["custom_attach_image"]:
                sku_img_uri = upload_image(variant["custom_attach_image"], use_case="ATTRIBUTE_IMAGE") or default_image_url

            # Lấy giá từ Item Price cho biến thể
            price, currency = get_item_price(variant["item_code"])
            if price is None:
                price = variant["standard_rate"] or item.standard_rate or 300000
                currency = default_currency

            skus.append({
                "sales_attributes": sales_attributes,
                "seller_sku": variant.get("custom_barcode_data") or variant["item_code"],
                "price": {"amount": str(price), "currency": currency},
                "inventory": [{"warehouse_id": default_warehouse_id, "quantity": int(variant["opening_stock"] or item.opening_stock or 1000)}],
                "sku_img": {"uri": sku_img_uri} if sku_img_uri != default_image_url else None,
                "package_weight": {"value": str(item.weight_per_unit or 0.2), "unit": "KILOGRAM"}
            })
    else:
        # Lấy giá từ Item Price cho sản phẩm chính
        price, currency = get_item_price(item.item_code)
        if price is None:
            price = item.standard_rate or 300000
            currency = default_currency

        skus.append({
            "seller_sku": item.get("custom_barcode_data") or item.item_code,
            "price": {"amount": str(price), "currency": currency},
            "inventory": [{"warehouse_id": default_warehouse_id, "quantity": int(item.opening_stock or 1000)}],
            "package_weight": {"value": str(item.weight_per_unit or 0.2), "unit": "KILOGRAM"}
        })

    if not skus:
        print(f"Không có SKU hợp lệ cho sản phẩm {item.name}")
        return None
    return skus

# Hàm phụ trợ chuẩn bị mô tả
def prepare_description(item):
    description = item.description or "<p>Vui lòng kiểm tra kích thước trước khi mua hàng.</p>"
    if hasattr(item, "custom_item_specification") and item.custom_item_specification:
        spec_html = "<ul>"
        for spec in item.custom_item_specification:
            spec_html += f"<li>{spec.specification}: {spec.value}</li>"
        spec_html += "</ul>"
        description += spec_html
    if hasattr(item, "custom_video") and item.custom_video:
        description += f"<p>Video sản phẩm: <a href='{item.custom_video}'>Xem video</a></p>"
    return description

# Hàm phụ trợ chuẩn bị kích thước bao bì
def prepare_package_dimensions(item):
    if hasattr(item, "length") and hasattr(item, "width") and hasattr(item, "height") and item.length and item.width and item.height:
        return {
            "length": str(item.length),
            "width": str(item.width),
            "height": str(item.height),
            "unit": "CENTIMETER"
        }
    return None

# Hàm phụ trợ chuẩn bị size chart
def prepare_size_chart(item, default_url):
    """Chuẩn bị size chart."""
    size_chart_image = getattr(item, "size_chart_image", None)
    # return {"image": {"uri": upload_image(size_chart_image, "SIZE_CHART") or default_url}}
    return {"image": {"uri": default_url}}

def prepare_certifications(item, certifications):
    """Chuẩn bị chứng nhận sản phẩm."""
    cert_files = []
    if hasattr(item, "custom_certification_files"):
        for cert in certifications:
            if cert["is_required"]:
                file_url = getattr(item, "custom_certification_files", None)  # Giả định là một trường chứa URL
                if file_url:
                    uri = upload_image(file_url, "CERTIFICATION")
                    if uri:
                        cert_files.append({"id": cert["id"], "uri": uri})
    return cert_files if cert_files else None

def prepare_manufacturer(item):
    """Chuẩn bị thông tin nhà sản xuất."""
    return getattr(item, "custom_manufacturer", None)

def prepare_responsible_person(item):
    """Chuẩn bị thông tin người chịu trách nhiệm."""
    return getattr(item, "custom_responsible_person", None)

def prepare_epr(item):
    """Chuẩn bị thông tin EPR."""
    return getattr(item, "custom_epr", None)

# Hàm chính tích hợp category rules
def prepare_product_data_tiktok_shop(item):
    """Chuẩn bị dữ liệu sản phẩm cho TikTok Shop với kiểm tra và ánh xạ từ category rules."""
    try:
        default_warehouse_id = "7483552233957639941"
        default_currency = "VND"
        default_image_url = "tos-maliva-i-o3syd03w52-us/ab2f4ec275cb4b949a2e626c3071596b"
        default_size_chart_url = "tos-maliva-i-o3syd03w52-us/a8cddea166d140b69212be9676b27580"

        # Lấy category_id
        category_id = get_tiktok_category_id(item.item_group)
        if not category_id:
            print(f"Thiếu category_id cho sản phẩm {item.name}")
            update_sync_status(item.name, "Failed", "Thiếu category_id")
            return None

        # Lấy và kiểm tra category rules
        rules = get_category_rules(category_id)
        if not rules:
            print(f"Không thể lấy quy tắc danh mục cho sản phẩm {item.name}")
            update_sync_status(item.name, "Failed", "Không thể lấy quy tắc danh mục")
            return None

        # Kiểm tra và thu thập lỗi
        errors = validate_category_rules(item, rules)
        if errors:
            error_msg = "; ".join(errors)
            print(f"Lỗi quy tắc danh mục cho sản phẩm {item.name}: {error_msg}")
            update_sync_status(item.name, "Failed", error_msg)
            return None

        # Chuẩn bị dữ liệu cơ bản
        product_data = {
            "title": item.item_name,
            "description": prepare_description(item),
            "category_id": category_id,
            "main_images": prepare_main_images(item, default_image_url),
            "skus": prepare_skus(item, default_warehouse_id, default_currency, default_image_url),
            "package_weight": {"value": str(item.weight_per_unit or 0.2), "unit": "KILOGRAM"}
        }

        # Từ điển ánh xạ quy tắc với hàm xử lý
        rule_handlers = {
            "size_chart": {
                "condition": lambda r: r.get("is_required"),
                "handler": lambda item, default: prepare_size_chart(item, default),
                "default": default_size_chart_url
            },
            "package_dimension": {
                "condition": lambda r: r.get("is_required"),
                "handler": prepare_package_dimensions,
                "default": None
            },
            "product_certifications": {
                "condition": lambda r: bool(r),  # Nếu danh sách không rỗng
                "handler": lambda item, certs: prepare_certifications(item, certs),
                "default": None
            },
            "manufacturer": {
                "condition": lambda r: r.get("is_required"),
                "handler": prepare_manufacturer,
                "default": None
            },
            "responsible_person": {
                "condition": lambda r: r.get("is_required"),
                "handler": prepare_responsible_person,
                "default": None
            },
            "epr": {
                "condition": lambda r: r.get("is_required"),
                "handler": prepare_epr,
                "default": None
            },
            "cod": {
                "condition": lambda r: r.get("is_supported") and hasattr(item, "custom_is_cod_allowed") and item.custom_is_cod_allowed,
                "handler": lambda item, _: {"is_cod_allowed": True},
                "default": None
            }
        }

        # Duyệt qua rules và thêm thuộc tính bắt buộc
        for rule_name, rule_value in rules.items():
            if rule_name in rule_handlers:
                handler_info = rule_handlers[rule_name]
                if handler_info["condition"](rule_value):
                    if rule_name == "product_certifications":
                        result = handler_info["handler"](item, rule_value)
                    else:
                        result = handler_info["handler"](item, handler_info["default"])
                    if result:
                        if rule_name == "cod":
                            product_data.update(result)
                        else:
                            product_data[rule_name] = result
                # Nếu không bắt buộc và rule_name là size_chart, không thêm vào product_data
                elif rule_name == "size_chart":
                    continue

        # Thêm ảnh bổ sung
        additional_images = prepare_additional_images(item)
        if additional_images:
            product_data["additional_images"] = additional_images
        
        # Điều chỉnh trạng thái sản phẩm
        product_data["status"] = "ON_SHELF" if not item.disabled else "OFF_SHELF"
        if not product_data["skus"]:
            update_sync_status(item.name, "Failed", "Không có SKU hợp lệ")
            return None

        return product_data
    except Exception as e:
        print(f"Lỗi khi chuẩn bị dữ liệu cho sản phẩm {item.name}: {str(e)}")
        frappe.log_error(message=f"Lỗi khi chuẩn bị dữ liệu cho sản phẩm {item.name}: {str(e)}", title="TikTok Shop Sync Error")
        update_sync_status(item.name, "Failed", str(e))
        return None

def update_sync_status(item_code, status, message=None):
    """Cập nhật trạng thái đồng bộ cho sản phẩm."""
    marketplace = "TikTok"  # Giả định TikTok vì đang sync với TikTok Shop
    try:
        # Kiểm tra xem mapping đã tồn tại chưa
        mapping = frappe.get_all(
            "Marketplace Item Mapping",
            filters={"item": item_code, "marketplace": marketplace},
            fields=["name"]
        )
        if mapping:
            doc = frappe.get_doc("Marketplace Item Mapping", mapping[0]["name"])
        else:
            doc = frappe.new_doc("Marketplace Item Mapping")
            doc.item = item_code
            doc.marketplace = marketplace
        
        doc.sync_status = status
        doc.last_sync_time = frappe.utils.now()
        doc.save()
        print(f"Saved mapping for {item_code} with status {status}")
        
        if message:
            frappe.log_error(
                message=f"Sync {item_code} ({marketplace}): {message}",
                title=f"Sync Status: {status}"
            )
    except Exception as e:
        print(f"Lỗi khi cập nhật trạng thái cho {item_code}: {str(e)}")

def save_mapping(item, marketplace_product_id, marketplace_sku, sync_status):
    """Lưu ánh xạ sản phẩm vào Marketplace Item Mapping."""
    try:
        existing_mapping = frappe.db.get_value("Marketplace Item Mapping", {"item": item.name})
        if existing_mapping:
            mapping_doc = frappe.get_doc("Marketplace Item Mapping", existing_mapping)
            # Làm mới tài liệu để tránh TimestampMismatchError
            mapping_doc.reload()
        else:
            mapping_doc = frappe.new_doc("Marketplace Item Mapping")
        
        mapping_doc.item = item.name
        mapping_doc.marketplace = "TikTok"  # Đổi thành "TikTok Shop" nếu cần khớp với cấu hình khác
        mapping_doc.marketplace_product_id = marketplace_product_id
        mapping_doc.marketplace_sku = marketplace_sku
        mapping_doc.last_sync_time = frappe.utils.now()
        mapping_doc.sync_status = sync_status
        
        mapping_doc.save()
        frappe.db.commit()
        print(f"Saved mapping for {item.name} with status {sync_status}")
    except Exception as e:
        # Cắt ngắn tiêu đề lỗi để tránh CharacterLengthExceededError
        error_title = f"Error saving mapping for {item.name}"[:100]  # Giới hạn 100 ký tự để an toàn
        frappe.log_error(f"{error_title}: {str(e)}")
        raise