import requests
import json
import frappe
import time
from sync_product_data.sync_product_data.tiktok_integration.utils import calculate_signature, get_tiktok_api

BASE_URL = "https://open-api.tiktokglobalshop.com"
HTTP_SUCCESS = 200
SUCCESS_CODE = 0

def create_tiktok_product(product_data):
    """Tạo sản phẩm mới trên TikTok Shop API."""
    tiktok_api = get_tiktok_api()
    if not tiktok_api:
        return None

    url = f"{BASE_URL}/product/202309/products"
    path = "/product/202309/products"
    headers = {"Content-Type": "application/json", "x-tts-access-token": tiktok_api.access_token}
    query_params = {
        "shop_cipher": tiktok_api.shop_cipher,
        "app_key": tiktok_api.app_key,
        "timestamp": str(int(time.time()))
    }
    signature = calculate_signature(tiktok_api.app_secret, query_params, path, product_data)
    query_params["sign"] = signature

    try:
        response = requests.post(url, params=query_params, headers=headers, json=product_data)
        if response.status_code == HTTP_SUCCESS and response.json().get("code") == SUCCESS_CODE:
            return response.json()
        frappe.log_error(f"Failed to create TikTok Product: {response.text}")
        return None
    except Exception as e:
        frappe.log_error(f"Error creating TikTok Product: {str(e)}")
        return None

def update_tiktok_product(product_id, product_data):
    """Cập nhật sản phẩm trên TikTok Shop API."""
    print(f"Updating TikTok Product {product_id}")
    tiktok_api = get_tiktok_api()
    if not tiktok_api or not product_id or not product_data:
        print("Missing API settings, product_id, or product_data")
        return None

    url = f"{BASE_URL}/product/202309/products/{product_id}"
    path = f"/product/202309/products/{product_id}"
    headers = {"Content-Type": "application/json", "x-tts-access-token": tiktok_api.access_token}
    query_params = {
        "app_key": tiktok_api.app_key,
        "shop_cipher": tiktok_api.shop_cipher,
        "timestamp": str(int(time.time()))
    }
    signature = calculate_signature(tiktok_api.app_secret, query_params, path, body=product_data, content_type=headers["Content-Type"])
    query_params["sign"] = signature

    try:
        response = requests.put(url, params=query_params, headers=headers, json=product_data)
        print(f"Update response: {response.status_code} - {response.text}")
        if response.status_code == HTTP_SUCCESS and response.json().get("code") == SUCCESS_CODE:
            return response.json()
        frappe.log_error(f"Failed to update TikTok Product {product_id}: {response.text}")
        return None
    except Exception as e:
        frappe.log_error(f"Error updating TikTok Product {product_id}: {str(e)}")
        return None

def delete_tiktok_product(product_ids):
    """Xóa sản phẩm trên TikTok Shop API."""
    print(f"Deleting TikTok Product IDs: {product_ids}")
    tiktok_api = get_tiktok_api()
    if not tiktok_api or not product_ids:
        print("Missing API settings or product_ids")
        return None

    if not isinstance(product_ids, list):
        product_ids = [product_ids]

    url = f"{BASE_URL}/product/202309/products"
    path = "/product/202309/products"
    headers = {"Content-Type": "application/json", "x-tts-access-token": tiktok_api.access_token}
    query_params = {
        "app_key": tiktok_api.app_key,
        "shop_cipher": tiktok_api.shop_cipher,
        "timestamp": str(int(time.time()))
    }
    delete_body = {"product_ids": product_ids}
    signature = calculate_signature(tiktok_api.app_secret, query_params, path, body=delete_body, content_type=headers["Content-Type"])
    query_params["sign"] = signature

    try:
        response = requests.delete(url, params=query_params, headers=headers, json=delete_body)
        print(f"Delete response: {response.status_code} - {response.text}")
        if response.status_code == HTTP_SUCCESS and response.json().get("code") == SUCCESS_CODE:
            return response.json()
        frappe.log_error(f"Failed to delete TikTok Product: {response.text}")
        return None
    except Exception as e:
        frappe.log_error(f"Error deleting TikTok Product: {str(e)}")
        return None