import frappe
import requests
import time
from sync_product_data.sync_product_data.tiktok_integration.utils import calculate_signature, get_tiktok_api

BASE_URL = "https://open-api.tiktokglobalshop.com"
HTTP_SUCCESS = 200
SUCCESS_CODE = 0


def get_categories():
    """Lấy danh sách danh mục sản phẩm từ TikTok Shop API."""
    print("Fetching TikTok Shop categories")
    tiktok_api = get_tiktok_api()
    if not tiktok_api:
        return None

    url = f"{BASE_URL}/product/202309/categories"
    path = "/product/202309/categories"
    query_params = {
        "app_key": tiktok_api.app_key,
        "shop_cipher": tiktok_api.shop_cipher,
        "shop_id": tiktok_api.shop_id,
        "timestamp": str(int(time.time())),
        "locale": "vi-VN"
    }
    signature = calculate_signature(tiktok_api.app_secret, query_params, path)
    query_params["sign"] = signature
    headers = {"content-type": "application/json", "x-tts-access-token": tiktok_api.access_token}

    try:
        response = requests.get(url, params=query_params, headers=headers)
        if response.status_code == HTTP_SUCCESS and response.json().get("code") == SUCCESS_CODE:
            return response.json().get("data", {}).get("categories", [])
        print(f"Failed to get categories: {response.text}")
        return None
    except Exception as e:
        print(f"Error fetching categories: {str(e)}")
        return None

def get_category_rules(category_id):
    """Lấy quy tắc danh mục từ TikTok Shop API."""
    tiktok_api = get_tiktok_api()
    path = f"/product/202309/categories/{category_id}/rules"
    try:
        url = BASE_URL + path.format(category_id=category_id)
        params = {
            "app_key": tiktok_api.app_key,
            "timestamp": str(int(time.time())),
            "shop_cipher": tiktok_api.shop_cipher,
        }
        headers = {
            "x-tts-access-token": tiktok_api.access_token,
            "content-type": "application/json"
        }
        signature = calculate_signature(tiktok_api.app_secret, params, path)
        params["sign"] = signature
        
        print(f"URL: {url}")
        print(f"Params: {params}")
        print(f"Headers: {headers}")
        
        response = requests.get(url, params=params, headers=headers)
        result = response.json()

        if result.get("code") == 0:
            print(f"Quy tắc danh mục {category_id}: {frappe.as_json(result['data'])}")
            return result["data"]
        else:
            print(f"Lỗi khi lấy quy tắc danh mục {category_id}: {result.get('message')}")
            return None
    except Exception as e:
        print(f"Lỗi khi gọi API Get Category Rules: {str(e)}")
        return None

def validate_category_rules(item, rules):
    """Kiểm tra các yêu cầu bắt buộc từ category rules."""
    errors = []
    
    # Không kiểm tra size_chart vì sẽ dùng default nếu bắt buộc
    if rules.get("package_dimension", {}).get("is_required"):
        if not (getattr(item, "length", None) and getattr(item, "width", None) and getattr(item, "height", None)):
            errors.append("Thiếu kích thước bao bì (package_dimension) bắt buộc")
    
    if rules.get("product_certifications"):
        required_certs = [cert["id"] for cert in rules["product_certifications"] if cert.get("is_required")]
        if required_certs and not hasattr(item, "custom_certification_files"):
            errors.append("Thiếu chứng nhận sản phẩm bắt buộc")
    
    if rules.get("manufacturer", {}).get("is_required") and not getattr(item, "custom_manufacturer", None):
        errors.append("Thiếu thông tin nhà sản xuất (manufacturer) bắt buộc")
    
    if rules.get("responsible_person", {}).get("is_required") and not getattr(item, "custom_responsible_person", None):
        errors.append("Thiếu thông tin người chịu trách nhiệm (responsible_person) bắt buộc")
    
    if rules.get("epr", {}).get("is_required") and not getattr(item, "custom_epr", None):
        errors.append("Thiếu thông tin EPR bắt buộc")
    
    return errors

def sync_tiktok_categories(platform="TikTok Shop"):
    """Đồng bộ danh mục từ TikTok Shop API vào Marketplace Category."""
    print(f"Syncing TikTok Shop categories for {platform}")
    categories = get_categories()
    if not categories:
        print("No categories fetched")
        return

    frappe.db.sql("DELETE FROM `tabMarketplace Category`")
    frappe.db.commit()
    print("Cleared existing Marketplace Category data")

    root_category_id = f"{platform.lower().replace(' ', '_')}_root"
    root_doc = frappe.new_doc("Marketplace Category")
    root_doc.category_name = f"{platform} Root"
    root_doc.category_id = root_category_id
    root_doc.platform = platform
    root_doc.is_leaf = 0
    root_doc.is_group = 1
    root_doc.permission_status = "AVAILABLE"
    root_doc.insert(ignore_permissions=True)
    root_name = root_doc.name
    frappe.db.commit()
    print(f"Created root category: {root_name}")

    category_map = {category["id"]: category for category in categories}
    remaining_categories = list(categories)
    inserted_categories = {root_category_id}

    while remaining_categories:
        inserted_count = 0
        for category in remaining_categories[:]:
            category_id = category["id"]
            parent_id = category["parent_id"]
            is_leaf = category["is_leaf"]
            local_name = category["local_name"]
            permission_status = category["permission_statuses"][0] if category["permission_statuses"] else "UNKNOWN"

            parent_name = root_name if parent_id == "0" else None
            if parent_id != "0":
                parent_doc = frappe.get_all("Marketplace Category", filters={"category_id": parent_id}, fields=["name"], limit=1)
                if not parent_doc:
                    continue
                parent_name = parent_doc[0]["name"]

            if parent_id == "0" or parent_id in inserted_categories:
                doc = frappe.new_doc("Marketplace Category")
                doc.category_name = local_name
                doc.category_id = category_id
                doc.platform = platform
                doc.is_leaf = 1 if is_leaf else 0
                doc.is_group = 0 if is_leaf else 1
                doc.permission_status = permission_status
                doc.parent_platform_category = parent_name
                doc.insert(ignore_permissions=True)
                print(f"Inserted category {category_id} under {parent_name}")
                inserted_categories.add(category_id)
                remaining_categories.remove(category)
                inserted_count += 1

        if inserted_count == 0 and remaining_categories:
            raise Exception(f"Could not insert remaining categories: {remaining_categories}")

    frappe.db.commit()
    frappe.msgprint("Successfully synced TikTok Shop categories")


def run_sync():
    sync_tiktok_categories()


if __name__ == "__main__":
    run_sync()