# sync_product_data/sync_product_data/tiktok_integration/tiktok_attribute_sync.py
import requests
import time
import frappe
from sync_product_data.sync_product_data.tiktok_integration.tiktok_shop_api import get_tiktok_api, calculate_signature, BASE_URL, HTTP_SUCCESS, SUCCESS_CODE

# Hàm lấy thuộc tính của danh mục
def get_category_attributes(app_key, app_secret, access_token, shop_cipher, category_id):
    print(f"Starting get_category_attributes for category_id: {category_id}")
    url = f"{BASE_URL}/product/202309/categories/{category_id}/attributes"
    path = f"/product/202309/categories/{category_id}/attributes"
    query_params = {
        "shop_cipher": shop_cipher,
        "app_key": app_key,
        "timestamp": str(int(time.time()))
    }
    signature = calculate_signature(app_secret, query_params, path)
    query_params["sign"] = signature
    headers = {"x-tts-access-token": access_token}
    print(f"Headers: {headers}, Query params: {query_params}")

    try:
        response = requests.get(url, params=query_params, headers=headers)
        print(f"Response status: {response.status_code}, body: {response.text}")
        if response.status_code == HTTP_SUCCESS:
            data = response.json()
            if data["code"] == SUCCESS_CODE:
                print(f"Successfully fetched attributes for category {category_id}")
                return data["data"]["attributes"]
        frappe.log_error(f"Failed to get attributes for category {category_id}: {response.text}")
        print(f"Failed to get attributes for category {category_id}: {response.text}")
        return []
    except Exception as e:
        frappe.log_error(f"Error in get_category_attributes for {category_id}: {str(e)}")
        print(f"Error in get_category_attributes for {category_id}: {str(e)}")
        return []

def sync_tiktok_attributes(item_group_doc, category_id, api_doc):
    """Hàm xử lý đồng bộ attributes từ TikTok Shop."""
    print(f"Starting attribute sync for Item Group {item_group_doc.name}, category {category_id}")
    
    # Lấy attributes từ TikTok Shop
    attributes = get_category_attributes(
        app_key=api_doc.app_key,
        app_secret=api_doc.app_secret,
        access_token=api_doc.access_token,
        shop_cipher=api_doc.shop_cipher,
        category_id=category_id
    )
    if not attributes:
        frappe.msgprint(f"Không tìm thấy attributes cho category {category_id} trên TikTok Shop")
        return

    # Cập nhật attributes vào Marketplace Attribute
    for attr in attributes:
        print(attr)
        update_marketplace_attribute(attr)

def update_marketplace_attribute(attr):
    """Cập nhật hoặc tạo mới attribute trong Marketplace Attribute."""
    attribute_id = attr.get("id")
    if not attribute_id:
        print(f"No attribute_id found in {attr}")
        return

    # Kiểm tra attribute đã tồn tại chưa
    existing = frappe.get_all("Marketplace Attribute",
        filters={"marketplace": "TikTok Shop", "attribute_id": attribute_id},
        limit=1
    )

    if not existing:
        # Tạo mới attribute, dùng "name" thay vì "attribute_name"
        attr_doc = frappe.get_doc({
            "doctype": "Marketplace Attribute",
            "marketplace": "TikTok Shop",
            "attribute_id": attr.get("id"),
            "attribute_name": attr.get("name"),  # Sửa từ "attribute_name" thành "name"
            "type": attr.get("type", "PRODUCT_PROPERTY"),
            "is_customizable": attr.get("is_customizable", 0)
        })
        attr_doc.insert(ignore_permissions=True)
        frappe.db.commit()
        frappe.logger().info(f"Added attribute {attribute_id} for TikTok Shop")
    else:
        frappe.logger().info(f"Attribute {attribute_id} already exists, skipping.")


@frappe.whitelist()
def sync_mapped_category_attributes():
    """Trích xuất thuộc tính từ các danh mục đã ánh xạ với Item Group."""
    print("Starting sync_mapped_category_attributes")
    
    # Lấy thông tin API TikTok
    tiktok_info = get_tiktok_api()
    if not tiktok_info:
        print("Failed to get TikTok API settings.")
        frappe.throw("Failed to get TikTok API settings.")
    
    app_key = tiktok_info.app_key
    app_secret = tiktok_info.app_secret
    access_token = tiktok_info.access_token
    shop_cipher = tiktok_info.shop_cipher
    
    # Kiểm tra cấu hình
    if not all([app_key, app_secret, access_token, shop_cipher]):
        missing = [k for k, v in {"app_key": app_key, "app_secret": app_secret, "access_token": access_token, "shop_cipher": shop_cipher}.items() if not v]
        print(f"Missing required API credentials: {missing}")
        frappe.throw(f"Missing required API credentials: {missing}")
    
    print(f"API Config: app_key={app_key}, shop_cipher={shop_cipher}")

    # Lấy danh sách category_id đã ánh xạ với Item Group
    mapped_categories = frappe.get_all("Marketplace Attribute Mapping",
        filters={"marketplace": "TikTok Shop"},
        fields=["category_id", "item_group"],
        distinct=True)
    
    if not mapped_categories:
        print("No mapped categories found in Marketplace Attribute Mapping.")
        frappe.msgprint("Chưa có danh mục nào được ánh xạ với Item Group trong Marketplace Attribute Mapping.")
        return "No mapped categories"

    category_ids = [cat["category_id"] for cat in mapped_categories]
    print(f"Found {len(category_ids)} mapped categories: {category_ids}")
    frappe.msgprint(f"Found {len(category_ids)} mapped categories: {category_ids}")

    all_attributes = {}
    for category in mapped_categories:
        category_id = category["category_id"]
        item_group = category["item_group"]
        print(f"Processing category: {category_id} (Item Group: {item_group})")
        attributes = get_category_attributes(app_key, app_secret, access_token, shop_cipher, category_id)
        
        if attributes:
            for attr in attributes:
                attr_id = attr["id"]
                if attr_id not in all_attributes:
                    all_attributes[attr_id] = {
                        "name": attr["name"],
                        "type": attr["type"],
                        "categories": [],
                        "values_by_category": {}
                    }
                all_attributes[attr_id]["categories"].append({
                    "id": category_id,
                    "item_group": item_group
                })
                all_attributes[attr_id]["values_by_category"][category_id] = [
                    {"id": v.get("id", ""), "name": v["name"]} for v in attr.get("values", [])
                ]
        time.sleep(1)  # Tránh vượt quá giới hạn API

    # Lưu vào Marketplace Attribute Mapping
    for attr_id, attr_data in all_attributes.items():
        for category in attr_data["categories"]:
            mapping = frappe.get_all("Marketplace Attribute Mapping",
                filters={"marketplace": "TikTok Shop", "category_id": category["id"], "marketplace_attribute_id": attr_id})
            if not mapping:
                doc = frappe.get_doc({
                    "doctype": "Marketplace Attribute Mapping",
                    "marketplace": "TikTok Shop",
                    "category_id": category["id"],
                    "item_group": category["item_group"],
                    "marketplace_attribute_id": attr_id,
                    "marketplace_attribute_name": attr_data["name"]
                })
                doc.insert()
                print(f"Inserted new mapping: {attr_id} for category {category['id']}")
            else:
                doc = frappe.get_doc("Marketplace Attribute Mapping", mapping[0]["name"])
                print(f"Updated existing mapping: {attr_id} for category {category['id']}")
            doc.save()
    
    frappe.db.commit()
    print("Sync completed successfully")
    frappe.msgprint("Attributes synced and updated in Marketplace Attribute Mapping.")
    return "Sync completed"

if __name__ == "__main__":
    sync_mapped_category_attributes()