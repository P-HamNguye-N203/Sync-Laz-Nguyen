import frappe
from sync_product_data.sync_product_data.tiktok_integration.utils import refresh_access_token, is_access_token_expired

def refresh_tiktok_token_scheduler():
    """Hàm scheduler để kiểm tra và làm mới TikTok Shop token định kỳ."""
    try:
        api_doc = frappe.get_doc("Tiktok Shop API")
        if is_access_token_expired(api_doc):
            print("Token sắp hết hạn, bắt đầu làm mới...")
            refresh_access_token(api_doc)
        else:
            print("Token vẫn còn hiệu lực, không cần làm mới.")
            frappe.logger().info(f"TikTok Shop token still valid until {api_doc.access_token_expiry}")
    except frappe.DoesNotExistError:
        frappe.log_error("TikTok Shop API settings not found", "refresh_tiktok_token_scheduler")
    except Exception as e:
        frappe.log_error(f"Error in scheduler: {str(e)}", "refresh_tiktok_token_scheduler")