import frappe
import requests
import os
import hmac
import hashlib
import json
import time
from urllib.parse import urljoin

BASE_URL = "https://open-api.tiktokglobalshop.com"
AUTH_URL = "https://auth.tiktok-shops.com"
HTTP_SUCCESS = 200
SUCCESS_CODE = 0

def calculate_signature(app_secret, params, path, body=None, content_type=None):
    """Tính chữ ký cho TikTok Shop API."""
    sorted_params = sorted(params.items())
    input_string = ''.join([f"{key}{value}" for key, value in sorted_params])
    string_to_sign = app_secret + path + input_string
    
    if content_type != "multipart/form-data" and body:
        body_string = json.dumps(body) if isinstance(body, dict) else str(body)
        string_to_sign += body_string
    
    string_to_sign += app_secret
    return hmac.new(
        app_secret.encode('utf-8'),
        string_to_sign.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()

def get_tiktok_api():
    """Lấy thông tin API từ TikTok Shop API Doctype."""
    try:
        return frappe.get_doc("Tiktok Shop API")
    except frappe.DoesNotExistError:
        frappe.log_error("TikTok Shop API settings not found")
        return None

def is_access_token_expired(api_doc):
    """Kiểm tra xem access token có hết hạn hay không."""
    if not api_doc.get("access_token_expiry"):
        return True
    
    current_time = int(time.time())
    expiry_time = int(api_doc.access_token_expiry)
    buffer_time = 300
    
    return current_time >= (expiry_time - buffer_time)

def refresh_access_token(api_doc):
    """Làm mới access token và cập nhật vào doctype."""
    url = f"{AUTH_URL}/api/v2/token/refresh"
    params = {
        "app_key": api_doc.app_key,
        "app_secret": api_doc.app_secret,
        "refresh_token": api_doc.refresh_token,
        "grant_type": "refresh_token"
    }
    
    try:
        print("Bắt đầu làm mới access token...")
        print(f"URL: {url}")
        print(f"Params: {params}")
        
        current_time = int(time.time())
        print(f"Thời gian hiện tại (Unix timestamp): {current_time}")
        
        response = requests.get(url, params=params)
        print(f"Trạng thái phản hồi: {response.status_code}")
        print(f"Nội dung phản hồi: {response.text}")
        
        if response.status_code != 200:
            frappe.log_error(f"Failed to refresh TikTok Shop token: {response.text}", "refresh_access_token")
            raise Exception(f"Refresh token failed with status {response.status_code}")
        
        data = response.json()
        if data.get("code") != 0:
            frappe.log_error(f"Refresh token error: {data.get('message')}", "refresh_access_token")
            raise Exception(f"Refresh token error: {data.get('message')}")
        
        access_token = data["data"]["access_token"]
        refresh_token = data["data"].get("refresh_token", api_doc.refresh_token)
        print(f"Access Token mới: {access_token}")
        print(f"Refresh Token: {refresh_token}")
        
        if "access_token_expire_in" in data["data"]:
            access_token_expiry = data["data"]["access_token_expire_in"]
        elif "expires_in" in data["data"]:
            access_token_expiry = current_time + data["data"]["expires_in"]
        else:
            frappe.log_error("No expiry info in response", "refresh_access_token")
            raise KeyError("Neither 'access_token_expire_in' nor 'expires_in' found")
        print(f"Thời gian hết hạn Access Token: {access_token_expiry}")
        
        refresh_token_expiry = data["data"].get("refresh_token_expire_in", api_doc.get("refresh_token_expiry"))
        print(f"Thời gian hết hạn Refresh Token: {refresh_token_expiry if refresh_token_expiry else 'Không có'}")
        
        api_doc.db_set("access_token", access_token)
        api_doc.db_set("refresh_token", refresh_token)
        api_doc.db_set("access_token_expiry", access_token_expiry)
        api_doc.db_set("refresh_token_expiry", refresh_token_expiry if refresh_token_expiry else None)
        
        frappe.db.commit()
        print("Đã cập nhật access token mới và commit vào database")
        
        frappe.logger().info(f"Refreshed TikTok Shop access token for app_key: {api_doc.app_key}")
        
    except Exception as e:
        frappe.log_error(f"Error refreshing TikTok Shop token: {str(e)}", "refresh_access_token")
        print(f"Lỗi xảy ra: {str(e)}")
        raise

def download_image(image_path):
    """Tải ảnh từ ERPNext về local tạm thời."""
    print(f"Downloading image: {image_path}")
    full_url = frappe.utils.get_url(image_path)
    if image_path.startswith("/private"):
        token = frappe.generate_hash(image_path, 10)
        full_url = f"{full_url}?token={token}"
    
    temp_file_name = f"temp_{image_path.split('/')[-1]}"
    temp_path = frappe.get_site_path("public", "files", temp_file_name)
    
    response = requests.get(full_url)
    if response.status_code == 200:
        with open(temp_path, "wb") as f:
            f.write(response.content)
        print(f"Image downloaded to: {temp_path}")
        return temp_path
    print(f"Failed to download image: {response.status_code}")
    return None

# Cache trong bộ nhớ
image_cache = {}

def load_image_cache():
    """Tải cache từ DocType Image Cache vào dictionary dựa trên image_hash."""
    cached_images = frappe.get_all(
        "Image Cache",
        fields=["image_path", "image_hash", "uri", "use_case"],
        filters={"use_case": ["in", ["MAIN_IMAGE", "ATTRIBUTE_IMAGE", "DESCRIPTION_IMAGE", "SIZE_CHART", "CERTIFICATION"]]}
    )
    for img in cached_images:
        if img.image_hash:  # Chỉ lưu nếu có hash
            image_cache[(img.image_hash, img.use_case)] = img.uri

def save_to_image_cache(image_path, image_hash, uri, use_case):
    """Lưu URI vào DocType Image Cache với image_hash."""
    existing = frappe.get_all(
        "Image Cache",
        filters={"image_path": image_path, "use_case": use_case},
        fields=["name"]
    )
    if existing:
        doc = frappe.get_doc("Image Cache", existing[0]["name"])
    else:
        doc = frappe.new_doc("Image Cache")
        doc.image_path = image_path
        doc.use_case = use_case
    doc.image_hash = image_hash
    doc.uri = uri
    doc.last_updated = frappe.utils.now()
    try:
        doc.save()
        if image_hash and uri:  # Chỉ cập nhật cache nếu có hash và URI hợp lệ
            image_cache[(image_hash, use_case)] = uri
    except Exception as e:
        print(f"Error saving to Image Cache: {str(e)}")

def upload_image(image_path, use_case="MAIN_IMAGE"):
    """Tải ảnh lên TikTok Shop API với cơ chế cache dựa trên hash nội dung."""
    if not image_path:
        return None

    print(f"Uploading image {image_path} for {use_case}")

    # Tải ảnh về tạm thời để tính hash
    temp_file = download_image(image_path)
    if not temp_file:
        return None

    # Tính hash của nội dung ảnh
    with open(temp_file, "rb") as f:
        image_content = f.read()
        image_hash = hashlib.sha256(image_content).hexdigest()

    # Kiểm tra cache trong bộ nhớ
    cache_key = (image_hash, use_case)
    if cache_key in image_cache:
        print(f"Using cached URI for {image_path} ({use_case}) with hash {image_hash}: {image_cache[cache_key]}")
        os.remove(temp_file)
        print(f"Cleaned up: {temp_file}")
        return image_cache[cache_key]

    # Kiểm tra trong doctype Image Cache nếu không có trong bộ nhớ
    cached = frappe.get_all(
        "Image Cache",
        filters={"image_hash": image_hash, "use_case": use_case},
        fields=["uri"],
        limit=1
    )
    if cached:
        uri = cached[0]["uri"]
        image_cache[cache_key] = uri
        print(f"Using cached URI from DB for {image_path} ({use_case}) with hash {image_hash}: {uri}")
        os.remove(temp_file)
        print(f"Cleaned up: {temp_file}")
        return uri

    # Lấy thông tin API TikTok
    tiktok_api = get_tiktok_api()
    if not tiktok_api:
        os.remove(temp_file)
        print(f"Cleaned up: {temp_file}")
        return None

    # Endpoint upload ảnh
    url = f"{BASE_URL}/product/202309/images/upload"
    path = "/product/202309/images/upload"
    headers = {"x-tts-access-token": tiktok_api.access_token}
    query_params = {
        "app_key": tiktok_api.app_key,
        "timestamp": str(int(time.time())),
    }
    signature = calculate_signature(tiktok_api.app_secret, query_params, path, content_type="multipart/form-data")
    query_params["sign"] = signature

    try:
        with open(temp_file, "rb") as f:
            files = {
                "data": (os.path.basename(temp_file), f, "image/jpeg"),
                "use_case": (None, use_case)
            }
            response = requests.post(url, params=query_params, headers=headers, files=files)
        
        result = response.json()
        if response.status_code == 200 and result.get("code") == 0:
            uri = result["data"]["uri"]
            print(f"Uploaded image, URI: {uri}")
            save_to_image_cache(image_path, image_hash, uri, use_case)
            return uri
        else:
            print(f"Failed to upload image: {response.text}")
            save_to_image_cache(image_path, image_hash, None, use_case)  # Lưu với URI null để ghi nhận lỗi
            return None
    except Exception as e:
        print(f"Error uploading image: {str(e)}")
        save_to_image_cache(image_path, image_hash, None, use_case)  # Lưu với URI null để ghi nhận lỗi
        return None
    finally:
        if os.path.exists(temp_file):
            os.remove(temp_file)
            print(f"Cleaned up: {temp_file}")

def get_tiktok_category_id(item_group):
    """Lấy category_id từ Item Group."""
    print(f"Fetching TikTok category for {item_group}")
    group_categories = frappe.get_all(
        "Item Group Category",
        filters={"parent": item_group, "parenttype": "Item Group", "ecommerce_platform": "TikTok Shop"},
        fields=["marketplace_category"],
        limit=1
    )
    if not group_categories:
        print(f"No TikTok Shop category mapping for {item_group}")
        return None
    return group_categories[0]["marketplace_category"]

# Tải cache khi khởi động
load_image_cache()