# Copyright (c) 2025, 1 and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class PlatformAccount(Document):
	# begin: auto-generated types
	# This code is auto-generated. Do not modify anything in this block.

	from typing import TYPE_CHECKING

	if TYPE_CHECKING:
		from frappe.types import DF

		access_token: DF.Data | None
		access_token_expiry: DF.Data | None
		app_key: DF.Data | None
		app_secret: DF.Data | None
		locale: DF.Data | None
		platform: DF.Literal["Shopee", "Tiktok Shop", "Lazada"]
		refresh_token: DF.Data | None
		refresh_token_expiry: DF.Data | None
		shop_cipher: DF.Data | None
		shop_id: DF.Data | None
		shop_name: DF.Data
		time_update: DF.Datetime | None
	# end: auto-generated types
	pass
