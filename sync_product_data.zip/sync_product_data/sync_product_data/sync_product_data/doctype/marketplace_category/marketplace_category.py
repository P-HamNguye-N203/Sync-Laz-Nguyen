# Copyright (c) 2025, 1 and contributors
# For license information, please see license.txt

# import frappe
from frappe.utils.nestedset import NestedSet


class MarketplaceCategory(NestedSet):
	# begin: auto-generated types
	# This code is auto-generated. Do not modify anything in this block.

	from typing import TYPE_CHECKING

	if TYPE_CHECKING:
		from frappe.types import DF

		category_id: DF.Data | None
		category_name: DF.Data | None
		is_group: DF.Check
		is_leaf: DF.Check
		lft: DF.Int
		marketplace: DF.Literal["TikTok Shop", "Lazada", "Shopee"]
		name_view: DF.Data | None
		old_parent: DF.Link | None
		parent_marketplace_category: DF.Link | None
		permission_status: DF.Data | None
		rgt: DF.Int
	# end: auto-generated types
	pass
