// Copyright (c) 2025, 1 and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Marketplace Category", {
// 	refresh(frm) {

// 	},
// });
