# Copyright (c) 2025, 1 and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestSpecificationTemplate(FrappeTestCase):
	pass
