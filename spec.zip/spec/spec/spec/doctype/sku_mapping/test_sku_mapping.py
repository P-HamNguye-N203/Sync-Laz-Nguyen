# Copyright (c) 2025, spec and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestSKUMapping(FrappeTestCase):
	pass
